#export CUDA_VISIBLE_DEVICES=0

for ((i=0;i<5;i++));
do

python train.py \
--model_type xlmroberta \
--do_train \
--do_eval_during_train \
--model_name_or_path ../xlmroberta/ \
--data_dir ../data/data_StratifiedKFold_42/data_origin_$i \
--output_dir ../checkpoints/cnn123/xlmroberta/$i \
--max_seq_length 60 \
--learning_rate 5e-5 \
--hidden_dropout_prob 0.1 \
--adam_epsilon 1e-8 \
--per_gpu_train_batch_size 4 \
--gradient_accumulation_steps 4 \
--num_train_epochs 10 \
--weight_decay 0
done







#
#python predict.py \
#--model_type xlmroberta \
#--vote_model_paths ../checkpoints/cnn123/xlmroberta/ \
#--predict_file ../data/test.csv \
#--predict_result_file ../prediction_result/result.csv


